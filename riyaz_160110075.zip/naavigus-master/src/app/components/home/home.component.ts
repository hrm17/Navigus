import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  searchText: any;
  products = [
    { product_url: 'assets/images/product01.jpg', product_name: 'Buzz', product_desc: 'You wonâ€™t discover a North American style amber lager like this.' },
    { product_url: 'assets/images/product05.jpg', product_name: 'Trashy Blonde', product_desc: 'You wonâ€™t discover a North American style amber lager like this.' },
    { product_url: 'assets/images/product06.png', product_name: 'Berliner Weisse', product_desc: 'You wonâ€™t discover a North American style amber lager like this.' },
    { product_url: 'assets/images/pro.png', product_name: 'Pilson Lager', product_desc: 'You wonâ€™t discover a North American style amber lager like this.' },
    { product_url: 'assets/images/product04.jpg', product_name: 'Avery Brown', product_desc: 'You wonâ€™t discover a North American style amber lager like this.' },
    { product_url: 'assets/images/product.png', product_name: 'Electric India', product_desc: 'You wonâ€™t discover a North American style amber lager like this.' }
  ];
  constructor() { }

  ngOnInit() {
  }

}
